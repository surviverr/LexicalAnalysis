编译：g++ lex.cpp Graph.cpp -o lex.exe
运行：lex.exe test/00/00.txt，第二个参数为路径